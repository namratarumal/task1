<?php
$con=mysqli_connect("localhost","gayatriinfotech_user","*MA6YE_Wd8B]","gayatriinfotech_gayatriinfotechphp");

?>